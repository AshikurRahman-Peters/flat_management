<style>
	.v-select {
		margin-bottom: 5px;
	}

	.v-select.open .dropdown-toggle {
		border-bottom: 1px solid #ccc;
	}

	.v-select .dropdown-toggle {
		padding: 0px;
		height: 25px;
	}

	.v-select input[type=search],
	.v-select input[type=search]:focus {
		margin: 0px;
	}

	.v-select .vs__selected-options {
		overflow: hidden;
		flex-wrap: nowrap;
	}

	.v-select .selected-tag {
		margin: 2px 0px;
		white-space: nowrap;
		position: absolute;
		left: 0px;
	}

	.v-select .vs__actions {
		margin-top: -5px;
	}

	.v-select .dropdown-menu {
		width: auto;
		overflow-y: auto;
	}

	#cashTransaction label {
		font-size: 13px;
	}

	#cashTransaction select {
		border-radius: 3px;
		padding: 0;
	}

	#cashTransaction .add-button {
		padding: 2.5px;
		width: 28px;
		background-color: #298db4;
		display: block;
		text-align: center;
		color: white;
	}

	#cashTransaction .add-button:hover {
		background-color: #41add6;
		color: white;
	}
</style>

<div id="cashTransaction" class="content">
	<div class="row" style="border-bottom: 1px solid #ccc;padding-bottom: 15px;margin-bottom: 15px;">
		<div class="col-md-12">
			<form @submit.prevent="AccountInsertExpense">
				<div class="row">
					<div class="col-md-5 col-md-offset-1">
						<div class="form-group">
							<label class="col-md-4 control-label">Transaction Id</label>
							<label class="col-md-1">:</label>
							<div class="col-md-7">
								<input type="text" v-model="accountCode" class="form-control" readonly>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-4 control-label">Transaction Type</label>
							<label class="col-md-1">:</label>
							<div class="col-md-7">
								<select class="form-control" v-model="expense_detail.payment_type" required>
									<option value="1">Cash Payment</option>
									<option value="2">Bank Payment</option>
									<input placeholder="Account Number" v-model="expense_detail.account_number" v-bind:style="{display: expense_detail.payment_type == '2' ? '' : 'none'}" type="text">
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-4 control-label">Expense</label>
							<label class="col-md-1">:</label>
							<div class="col-md-6">
								<select class="form-control" v-model="expense_detail.type">
									<option :value="expense.id" v-for="expense in expenses">{{expense.expense_name}}</option>
								</select>

							</div>
							<div class="col-md-1" style="padding-left:0;margin-left: 16px;">
								<a href="/account" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
							</div>
						</div>
					</div>

					<div class="col-md-5">
						<div class="form-group">
							<label class="col-md-4 control-label">Date</label>
							<label class="col-md-1">:</label>
							<div class="col-md-7">
								<input type="date"  v-model="expense_detail.date" class="form-control" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-4 control-label">Description</label>
							<label class="col-md-1">:</label>
							<div class="col-md-7">
								<input type="text"  v-model="expense_detail.description" class="form-control">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-4 control-label">Amount</label>
							<label class="col-md-1">:</label>
							<div class="col-md-7">
								<input type="number"  v-model="expense_detail.taka" class="form-control" required>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-7 col-md-offset-5">
								<input type="submit" class="btn btn-success btn-sm" value="Save">
							
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="widget-box">
		<div class="widget-body" id="list">
			<div class="widget-main">
				<div class="row">
					<div class="col-md-12">
						<div id="accountsTable" class="table-responsive">

							<div class="content">
								<div class="row">
									<div class="col-md-12">
										<div class="card">
											<div class="card-header">
												<div class="widget-header">
													<h4 class="widget-title">Account List</h4>
												</div>
											</div>
											<div class="card-body">
												<div class="toolbar">
													<!--        Here you can write extra buttons/actions for the toolbar              -->
												</div>
												<table id="datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
													<thead>
														<tr>
															<th>SI ID</th>
															<th>Expense Name</th>
															<th>Description</th>
															<th>Date</th>
															<th>Amount</th>
															<th class="disabled-sorting text-right">Actions</th>
														</tr>
													</thead>
													<tbody>

														<tr v-for="expense in expense_details">

															<td>{{expense.code}}</td>
															<td hidden>{{expense.expense_id}}</td>
															<td>{{expense.expense_name}}</td>
															<td>{{expense.description}}</td>
															<td>{{expense.date}}</td>
															<td>{{expense.taka}}</td>
															<td class="text-right">
																<a style="cursor:pointer" @click="edit_Amount_expense_name(expense)">
																	<i class="fa fa-edit" style="color:green"></i></a>
																<a @click="DeleteAmountExpense(expense.expense_id)" class="btn btn-danger btn-link btn-icon btn-sm"><i class="fa fa-times"></i></a>
															</td>
														</tr>

													</tbody>
												</table>
											</div>
											<!-- end content-->
										</div>
										<!--  end card  -->
									</div>
									<!-- end col-md-12 -->
								</div>
								<!-- end row -->
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
	.form-group .form-control {
		padding: 5px;
	}

	.form-group {
		margin: 0px;
	}

	label {
		margin: 0px;
	}

	.table>tbody>tr>td {
		padding: 0px;
	}

	.table-responsive {
		overflow: hidden;
	}

	h4 {
		margin: 0px;
	}

	.table>thead>tr>th {
		padding: 5px;
	}
</style>

<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<script src="<?php echo base_url(); ?>/assets/js/core/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/core/popper.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/core/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/moment.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/bootstrap-switch.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/sweetalert2.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/jquery.bootstrap-wizard.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/bootstrap-selectpicker.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/bootstrap-datetimepicker.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/bootstrap-tagsinput.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/jasny-bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/fullcalendar.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/jquery-jvectormap.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/plugins/nouislider.min.js"></script>


<style>
	.form-group .form-control {
		padding: 5px;
	}

	.form-group {
		margin-bottom: 0px;
	}

	label {
		margin: 0px;
	}
</style>
<script src="<?php echo base_url(); ?>assets/js/vue/vue.js"></script>
<script src="<?php echo base_url(); ?>assets/js/vue/axios.js"></script>
<script src="<?php echo base_url(); ?>assets/js/vue/vuejs-datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/js/vue/vue-select.min.js"></script>


<script>
	Vue.component('v-select', VueSelect.VueSelect);
	new Vue({
		el: '#cashTransaction',
		data() {
			return {
				expenses: [],
				expense: {
					payment_type: null,
					expense_id: null,
					id:null,
				},
				accountCode: null,
				expense_details:[],
				expense_detail: {
					expense_name: null,
					description: null,
					expense_id: null,
					payment_type: null,
					accountCode: null,
					account_number:null,
					taka:null,
					type:null,
					id:null
				},
				selectExpense: null,
			

			}
		},
		created() {
			this.get_expense();
			this.getExpenseCode();
			this.get_account_expense();
		},
		methods: {
			get_expense() {
				axios.get('/get_expense').then(res => {
					this.expenses = res.data;
				})
			},

			getExpenseCode() {
				axios.get("/get_expense_code").then(res => {
					this.accountCode = res.data;
				})
			},
			get_account_expense() {
				axios.get("/get_account_expense").then(res => {
					this.expense_details = res.data;
				})
			},
			


			AccountInsertExpense() {

				console.log(this.expense_detail);
			    let url = "/account_expense_insert";
			    if (this.expense_detail.expense_id != null) {
			        url = "/account_update_expense";
			    }
			    if (this.expense_detail == '') {
			        alert('filed not be empty');
			        return;
			    }
			    axios.post(url, this.expense_detail).then(res => {
			        // this.expense_details = res.data;
			        console.log(res.data);
			    })
				location.reload();
			 
			},
			edit_Amount_expense_name(expense_detail) {

			    let keys = Object.keys(this.expense_detail);
			    keys.forEach(key => {
			        this.expense_detail[key] = expense_detail[key];
			    });
			    this.accountCode = expense_detail.code;
			},
			DeleteAmountExpense(expense_id) {
			    let deleteConfirm = confirm('Are you sure?');
			    if (deleteConfirm == false) {
			        return;
			    }
			    axios.post('/deleteAccountExpense', {
			        expense_id: expense_id
			    }).then(res => {
			        let r = res.data;
			        alert(r.message);
			        if (r.success) {

			        }
			    })
			    location.reload();
			}

		}
	})
</script>